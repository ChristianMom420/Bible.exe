// Drawing Basics

// Setup the canvas and the graphics context
let cnv = document.getElementById("canvas");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;

// Store images in variables
let dogImg = document.getElementById("dog")




// Let's draw some stuff using the graphics context (ctx)
// Draw Rectangle


ctx.strokeStyle = "purple";

ctx.strokeRect (10, 10, 20, 20) //Draw an outlined rectangle

ctx.fillStyle = "green"

ctx.fillRect(225,50, 50, 50); //Draw filled squiare

// Draw text
ctx.font = "42px Comic Sans MS";

ctx.fillStyle = "red";

ctx.fillText("F", 00, 300)

ctx.font = "30px Arial";
ctx.strokeStyle = "blue"
ctx.strokeText("E", 20, 320)

ctx.font = "55px Comic Sans MS";
ctx.fillStyle = "blue"
ctx.fillText("Duncan", 20, 420)
ctx.font = "50px Comic Sans MS";
ctx.fillStyle = "green"
ctx.fillText("Duncan", 20, 420)


// dRAW LIneS
ctx.lineWidth = 4;
ctx.strokeStyle = "orange"
ctx.beginPath();
ctx.moveTo(500, 200); //set start poitn 
ctx.lineTo(700, 150); // Draw line from start to current
ctx.lineTo(600, 50)
ctx.stroke(); // Draw path 

ctx.lineWidth = 4;
ctx.strokeStyle = "cyan"
ctx.beginPath();
ctx.moveTo(500, 500);
ctx.lineTo(700, 450);
ctx.lineTo(600, 350);
ctx.closePath();
ctx.stroke();




ctx.lineWidth = 1;
ctx.strokeStyle = "black";
ctx.beginPath();
ctx.arc(100, 500, 50, 0, 2 * Math.PI);
ctx.stroke();

ctx.lineWidth = 2;
ctx.fillStyle = "green";
ctx.beginPath();
ctx.arc(100, 500, 20, 0, 2 * Math.PI);
ctx.fill();

ctx.lineWidth = 1;
ctx.strokeStyle = "black";
ctx.beginPath();
ctx.arc(200, 500, 40, 0, 2 * Math.PI);
ctx.stroke();

ctx.lineWidth = 2;
ctx.fillStyle = "green";
ctx.beginPath();
ctx.arc(200, 500, 15, 0, 2 * Math.PI);
ctx.fill();

// Draw images
ctx.drawImage(dogImg, 200, 200); // Draw from top left
ctx.drawImage(dogImg, 200, 350, 50, 50); //Draw image with top left corner of scale 50x50