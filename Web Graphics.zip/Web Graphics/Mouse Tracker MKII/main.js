// Add event listeners

document.addEventListener("mousemove", mousemoveHandler);

// Setup canvas

let cnv = document.getElementById("canv");
let ctx = cnv.getContext("2d");
cnv.height = 750;
cnv.width = 1200;
let circRed = 0;
let circGreen = 0;
let circBlue = 0;
let red = false;
let green = false;
let blue = false;
let redNum = 0;
let blueNum = 0;
let greenNum = 0;
let run = 0;
let rise = 0;
let hypotenuse = 0;
let circH = 5
let circRu = 0;
let circRi = 0;
let holderA = 0;
let holderB = 0;
let holderC = 0;
let face = document.getElementById("img")
let money = document.getElementById("money")

// Variables

let circX = 600;
let circY = 375;
let mouseX, mouseY, pmouseX, pmouseY


requestAnimationFrame(loop)

function loop() {
    // Draw a background

    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, cnv.width, cnv.height)

// Draw circle

ctx.drawImage(face, circX - 25, circY - 25, 50, 50)
ctx.drawImage(money, mouseX - 40, mouseY - 20, 80, 40)

//Method 2

//if (circX < mouseX && circX < 1180) {
//    circX = circX + (mouseX - circX) / 20
//
//} else if (circX > mouseX && circX > 20) {
//    circX = circX - (circX - mouseX) / 20
//}
//
//if (circY < mouseY && circY < 730) {
//    circY = circY + (mouseY - circY) / 20
//} else if (circY > mouseY && circY > 20) {
///    circY = circY - (circY - mouseY) / 20
//}

//Method 3



if (circX > mouseX && circY > mouseY && circX > 25 && circY > 25) {

    run = circX - mouseX
    rise = circY - mouseY
    hypotenuse = Math.sqrt(run ** 2 + rise ** 2)


    if (hypotenuse >= 5) {
    holderA = hypotenuse / 5

    holderB = run * rise

    circRu = run / holderA

    circRi = rise / holderA

    circX = circX - circRu
    circY = circY - circRi

    } 


} else if (circX < mouseX && circY > mouseY && circX < 1175 && circY > 25) {
    run = mouseX - circX
    rise = circY - mouseY
    hypotenuse = Math.sqrt(run ** 2 + rise ** 2)

    if (hypotenuse >= 5) {
    holderA = hypotenuse / 5

    holderB = run * rise

    circRu = run / holderA

    circRi = rise / holderA

    circX = circX + circRu
    circY = circY - circRi
    }

} else if (circX < mouseX && circY < mouseY && circX < 1175 && circY < 725) {
    run = mouseX - circX
    rise = mouseY - circY
    hypotenuse = Math.sqrt(run ** 2 + rise ** 2)

    if (hypotenuse >= 5) {
    holderA = hypotenuse / 5

    holderB = run * rise

    circRu = run / holderA

    circRi = rise / holderA

    circX = circX + circRu
    circY = circY + circRi
    }

} else if (circX > mouseX && circY < mouseY && circX > 25 && circY < 725) {
    run = circX - mouseX
    rise = mouseY - circY
    hypotenuse = Math.sqrt(run ** 2 + rise ** 2)

    if (hypotenuse >= 5) {
    holderA = hypotenuse / 5

    holderB = run * rise

    circRu = run / holderA

    circRi = rise / holderA

    circX = circX - circRu
    circY = circY + circRi
    }
    
} else if (circX == mouseX && circY == mouseY) {
    circX = mouseX
    circY = mouseY
}




requestAnimationFrame(loop)
}

function mousemoveHandler(event) {
    // Save previous mouseX and mouseY
    pmouseX = mouseX;
    pmouseY = mouseY

    // Update mouseX and mouseY

    let cnvCirc = cnv.getBoundingClientRect();
    mouseX = event.x  -  cnvCirc.x;
    mouseY = event.y  -  cnvCirc.y;
}

redPlus()

function redPlus() {
    if (circRed <= 250) {
        circRed++
        setTimeout(redPlus, 1);
    } else {
        redMinus()
        greenPlus()
    }
}

function redMinus() {
    if (circRed >=1) {
        circRed--
        setTimeout(redMinus, 1);
    } else {
        redPlus()
    }
}

function greenPlus() {
    if (circGreen <=250) {
        circGreen++
        setTimeout(greenPlus, 1);
    } else {
        greenMinus()
        bluePlus()
    }
}

function greenMinus() {
    if (circGreen >=1) {
        circGreen--
        setTimeout(greenMinus, 1);
    } else {
        greenPlus()
    }
}

function bluePlus() {
    if (circBlue <=250) {
        circBlue++
        setTimeout(bluePlus, 1)
    } else {
        blueMinus()
        redPlus()
    }
}

function blueMinus() {
    if (circBlue >=1) {
        circBlue--
        setTimeout(blueMinus, 1);
    } else {
        bluePlus()
    }
}
