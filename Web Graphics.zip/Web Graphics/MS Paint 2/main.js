// Microsoft Paint

// Setup Canvas and Graphics Context
let cnv = document.getElementById("myCanvas");
let ctx = cnv.getContext("2d");
cnv.width = 1000;
cnv.height = 600;

// Global Variables
let mouseIsPressed = false;
let mouseX, mouseY, pmouseX, pmouseY
let size = 5;
let penColor = "black"
let NKFlag = document.getElementById("NKFlag")
let stamp = false;
let stampB = false;
let imgX = 100;
let imgY = 50;
let soviet = document.getElementById("stampB")

// Main Program Loop (60 FPS)
requestAnimationFrame(loop);

function loop() {
    // Update Variables

    // Draw a circle if mouseIsPressed
    if (mouseIsPressed && stamp == false && stampB == false) {
        ctx.strokeStyle = penColor
        ctx.lineWidth = size;
        ctx.beginPath();
        ctx.lineCap = "round";
        ctx.moveTo(pmouseX, pmouseY);
        ctx.lineTo(mouseX, mouseY)
        ctx.stroke();
    } else if (mouseIsPressed && stamp == true) {
        ctx.drawImage(NKFlag, mouseX - (imgX / 2), mouseY - (imgY / 2), imgX, imgY)
    } else if (mouseIsPressed && stampB == true) {
        ctx.drawImage(soviet, mouseX - (imgX / 2), mouseY - (imgY / 2), imgX, imgY)
    }
    
    requestAnimationFrame(loop);
}

// Document Event stuff
document.addEventListener("mousedown", mousedownHandler);
document.addEventListener("mouseup", mouseupHandler);
document.addEventListener("mousemove", mousemoveHandler);
document.addEventListener("keydown", keydownHandler);


function mousedownHandler(event) {
    
    mouseIsPressed = true;
}

function mouseupHandler() {
    mouseIsPressed = false;
}

function mousemoveHandler(event) {
    // Save previous mouseX and mouseY
    pmouseX = mouseX;
    pmouseY = mouseY

    // Update mouseX and mouseY

    let cnvRect = cnv.getBoundingClientRect();
    mouseX = event.x  -  cnvRect.x;
    mouseY = event.y  -  cnvRect.y;
//    console.log(event);
}

function keydownHandler(event) {
//    console.log(event)
    if (event.code == "Space") {
        // Draw a background
        ctx.fillStyle = "white";
        ctx.fillRect(0, 0, cnv.width, cnv.height)
    } else if (event.code == "ArrowUp") {
        size++
        imgY++
        imgX = imgX + 2
    } else if (event.code == "ArrowDown") {
        size--
        imgY--
        imgX = imgX - 2;
    } else if (event.code == "Digit1") {
        penColor = "black"
        document.getElementById("black").classList.add("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
    } else if (event.code == "Digit2") {
        penColor = "red"
        document.getElementById("red").classList.add("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
    } else if (event.code == "Digit3") {
        penColor = "rgb(0, 221, 0)"
        document.getElementById("green").classList.add("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
    } else if (event.code == "Digit4") {
        penColor = "blue"
        document.getElementById("blue").classList.add("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
    } else if (event.code == "Digit5") {
        penColor = "yellow"
        document.getElementById("yellow").classList.add("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
    } else if (event.code == "Digit6") {
        penColor = "white"
        stampB = false;
        document.getElementById("eraser").classList.add("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
    }  else if (event.code == "Digit7") {
        stamp = true
        stampB = false;
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("stamp").classList.add("stamp")
        document.getElementById("stampB").classList.remove("stampB")
    } else if (event.code == "Digit8") {
        stampB = true;
        stamp = false;
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("stampB").classList.add("stampB")
        document.getElementById("stamp").classList.remove("stamp")
    }

    if (size < 1) {
        size++
    }
    if (imgX <1) {
        imgX = imgX + 2
    }
    if (imgY < 1) {
        imgY++
    }
}

// Color Events
document.getElementById("black").addEventListener("click", setBlack);
document.getElementById("red").addEventListener("click", setRed);
document.getElementById("green").addEventListener("click", setGreen);
document.getElementById("blue").addEventListener("click", setBlue);
document.getElementById("yellow").addEventListener("click", setYellow);
document.getElementById("eraser").addEventListener("click", setEraser);
document.getElementById("colorBtn").addEventListener("change", changeColor);
document.getElementById("stamp").addEventListener("click", setStamp)
document.getElementById("stampB").addEventListener("click", setStampB)


function setBlack() {
    penColor = "black"
    document.getElementById("black").classList.add("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
}

function setRed() {
    penColor = "red"
    document.getElementById("red").classList.add("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
}

function setGreen() {
    penColor = "rgb(0, 221, 0)"
    document.getElementById("green").classList.add("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
    
}

function setBlue() {
    penColor = "blue"
    document.getElementById("blue").classList.add("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
}

function setYellow() {
    penColor = "yellow"
    document.getElementById("yellow").classList.add("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("eraser").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
}

function setEraser() {
    penColor = "white"
    document.getElementById("eraser").classList.add("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        stamp = false;
        stampB = false;
}

function setStamp() {
    stamp = true;
    stampB = false;
    document.getElementById("eraser").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("stamp").classList.add("stamp")
}

function setStampB() {
    stamp = false;
    stampB = true;
    document.getElementById("eraser").classList.remove("active")
        document.getElementById("red").classList.remove("active")
        document.getElementById("green").classList.remove("active")
        document.getElementById("blue").classList.remove("active")
        document.getElementById("yellow").classList.remove("active")
        document.getElementById("black").classList.remove("active")
        document.getElementById("stamp").classList.remove("stamp")
        document.getElementById("stampB").classList.add("stampB")
}

function changeColor() {
    penColor = document.getElementById("colorBtn").value;
}