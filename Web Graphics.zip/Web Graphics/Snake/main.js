// GRID WALKER

// Add a bunch of divs to main
for (let row = 0; row < 36; row++) {
    for (let col = 0; col < 36; col++) {
document.getElementById("main").innerHTML += "<div id='cell" + row + "-" + col + "'></div>";
    }
}


// Global Variables for grid walker
let walkerRow = 18;
let walkerCol = 18;
let timer = 0;
let size = 1;
let movingRight = true;
let movingLeft = false;
let movingUp = false;
let movingDown = false;

// Highlight current walker cell
let walkerId = "cell" + walkerRow + "-" + walkerCol;
document.getElementById(walkerId).classList.add("active");

// Cjamge grod walker location on keydown
document.addEventListener("keydown", checkKeyPress);

function checkKeyPress(event) {
    //Remove active class from current location
    let walkerId = "cell" + walkerRow + "-" + walkerCol;
    document.getElementById(walkerId).classList.remove("active");

    if (event.keyCode == 37) {
        // Left arrow
        movingLeft = true;
        movingUp = false;
        movingDown = false;
        movingRight = false;
//        walkerCol--;
        
    } else if (event.keyCode == 39) {
        // Right arrow

        movingLeft = false;
        movingUp = false;
        movingDown = false;
        movingRight = true;
//        walkerCol++;
    } else if (event.keyCode == 38) {
        // Up arrow
        movingLeft = false;
        movingUp = true;
        movingDown = false;
        movingRight = false;
//        walkerRow--;
    } else if (event.keyCode == 40) {
        // Down arrow
        movingLeft = false;
        movingUp = false;
        movingDown = true;
        movingRight = false;
//        walkerRow++;
    } 

    if (walkerRow <=-1) {
        walkerRow++
    }
    else if (walkerRow >=36) {
        walkerRow--
    }
    if (walkerCol <=-1) {
        walkerCol++
    } else if (walkerCol >=36) {
        walkerCol--
    }






// Add active class



walkerId = "cell" + walkerRow + "-" + walkerCol;
document.getElementById(walkerId).classList.add("active");
}

// Movement interval loop


setInterval(loop, 100)

function loop() {

    //Remove active class from current location
    
//    let walkerId = "cell" + walkerRow + "-" + walkerCol;
//    document.getElementById(walkerId).classList.remove("active");
   

    if (movingRight && walkerCol <= 34) {
        walkerCol++;
        timer++
    }
    if (movingLeft && walkerCol >= 1) {
        walkerCol--;
        timer++
    }
    if (movingUp && walkerRow >= 1) {
        walkerRow--;
        timer++
    }
    if (movingDown && walkerRow <= 34) {
        walkerRow++;
        timer++
    }


    walkerId = "cell" + walkerRow + "-" + walkerCol;
document.getElementById(walkerId).classList.add("active");
}

requestAnimationFrame(time)

function time() {
    if (timer == 5) {
        size++
        timer = 0;
    }
    requestAnimationFrame(time)
}