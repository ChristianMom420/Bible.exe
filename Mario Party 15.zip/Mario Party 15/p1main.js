

// Setup Canvas and Graphics Context
let cnv = document.getElementById("canv");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;

// Add event listeners

document.addEventListener("keydown", keydownhandler)
document.getElementById("restart").addEventListener("click", reload)


// Define variables
let ship = document.getElementById("spaceship");
let alien = document.getElementById("invader");
let back = document.getElementById("back");
let laser = document.getElementById("laser");
let victory = document.getElementById("win");
let loss = document.getElementById("loss");
let life = document.getElementById("life");
let empty = document.getElementById("empty");
let shipX = 375;
let laserX = 0;
let laserY = 0;
let shooting = false;
let cooldown = false;
let score = 0;
let lives = 3;


// Enemy lives
let enemy1 = true;
let enemy2 = true;
let enemy3 = true;
let enemy4 = true;
let enemy5 = true;
let enemy6 = true;
let enemy7 = true;
let enemy8 = true;
let enemy9 = true;
let enemy10 = true;
let enemy11 = true;
let enemy12 = true;
let enemy13 = true;
let enemy14 = true;
let enemy15 = true;
let enemy16 = true;

// Enemy Positions

let x1 = 50;
let y1 = 50;
let x2 = 150;
let y2 = 50;
let x3 = 260;
let y3 = 50;
let x4 = 370;
let y4 = 50;
let x5 = 480;
let y5 = 50;
let x6 = 590;
let y6 = 50;
let x7 = 700;
let y7 = 50;
let x8 = 50;
let y8 = 150;
let x9 = 150;
let y9 = 150;
let x10 = 260;
let y10 = 150;
let x11 = 370;
let y11 = 150;
let x12 = 480;
let y12 = 150;
let x13 = 590;
let y13 = 150;
let x14 = 700;
let y14 = 150;



// functions

function keydownhandler(event) {
    if (event.code == "ArrowLeft") {
        if (shipX >= 20) {
        shipX = shipX - 40;
        }
    } else if (event.code == "ArrowRight") {
        if (shipX <= 700) {
        shipX = shipX + 40;
        }
    } else if (event.code == "ArrowUp" && cooldown == false) {
        laserY = 490
        laserX = shipX + 20
        shooting = true;
        cooldown = true;
        setTimeout(cool, 1000)
    }
}

function cool() {
    cooldown = false;
}

function reload() {
    location.reload()
}

function lose() {
    ctx.drawImage(loss, 300, 200, 200, 200)
    enemy1 = false;
    enemy2 = false;
    enemy3 = false;
    enemy4 = false;
    enemy5 = false;
    enemy6 = false;
    enemy7 = false;
    enemy8 = false;
    enemy9 = false;
    enemy10 = false;
    enemy11 = false;
    enemy12 = false;
    enemy13 = false;
    enemy14 = false;

}


// Looping function

setInterval(loop, 10)

function loop() {


    ctx.drawImage(back, 0, 0, cnv.width, cnv.height)

    ctx.drawImage(ship, shipX, 500, 50, 50)

// Lives loops

if (lives == 3) {
    ctx.drawImage(life, 10, 10, 50, 50)
    ctx.drawImage(life, 60, 10, 50, 50)
    ctx.drawImage(life, 110, 10, 50, 50)
} else if (lives == 2) {
    ctx.drawImage(life, 10, 10, 50, 50)
    ctx.drawImage(life, 60, 10, 50, 50)
    ctx.drawImage(empty, 110, 10, 50, 50)
} else if (lives == 1) {
    ctx.drawImage(life, 10, 10, 50, 50)
    ctx.drawImage(empty, 60, 10, 50, 50)
    ctx.drawImage(empty, 110, 10, 50, 50)
} else{
    ctx.drawImage(empty, 10, 10, 50, 50)
    ctx.drawImage(empty, 60, 10, 50, 50)
    ctx.drawImage(empty, 110, 10, 50, 50)
    lose()
}

    

// Laser loops
    if (shooting) {
        ctx.drawImage(laser, laserX, laserY, 10, 10)
        laserY = laserY - 5;
        if (laserY <= 0) {
            shooting = false;
        }
    }

if (laserX <= x1 + 50 && laserY <= y1 + 50 && laserX >= x1 && laserY >= y1) {
    enemy1 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x2 + 50 && laserY <= y2 + 50 && laserX >= x2 && laserY >= y2) {
    enemy2 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x3 + 50 && laserY <= y3 + 50 && laserX >= x3 && laserY >= y3) {
    enemy3 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x4 + 50 && laserY <= y4 + 50 && laserX >= x4 && laserY >= y4) {
    enemy4 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x5 + 50 && laserY <= y5 + 50 && laserX >= x5 && laserY >= y5) {
    enemy5 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x6 + 50 && laserY <= y6 + 50 && laserX >= x6 && laserY >= y6) {
    enemy6 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x7 + 50 && laserY <= y7 + 50 && laserX >= x7 && laserY >= y7) {
    enemy7 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x8 + 50 && laserY <= y8 + 50 && laserX >= x8 && laserY >= y8) {
    enemy8 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x9 + 50 && laserY <= y9 + 50 && laserX >= x9 && laserY >= y9) {
    enemy9 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x10 + 50 && laserY <= y10 + 50 && laserX >= x10 && laserY >= y10) {
    enemy10 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x11 + 50 && laserY <= y11 + 50 && laserX >= x11 && laserY >= y11) {
    enemy11 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x12 + 50 && laserY <= y12 + 50 && laserX >= x12 && laserY >= y12) {
    enemy12 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x13 + 50 && laserY <= y13 + 50 && laserX >= x13 && laserY >= y13) {
    enemy13 = false;
    laserY = laserY- 500
    score = score + 10;
}

if (laserX <= x14 + 50 && laserY <= y14 + 50 && laserX >= x14 && laserY >= y14) {
    enemy14 = false;
    laserY = laserY- 500
    score = score + 10;
}

// Enemy loops
    if (enemy1 && y1 <= 500) {
        ctx.drawImage(alien, x1, y1, 50, 50)
        y1 = y1 + 0.15
        
    } else if (y1 >= 500 && enemy1) {
        lives--
        enemy1 = false;
    } else {
        enemy1 = false;
        y1 = y1 - 5000;
        x1 = x1 - 5000;
    }

    if (enemy2 && y2 <= 500) {
        ctx.drawImage(alien, x2, y2, 50, 50)
        y2 = y2 + 0.15
    } else if (y2 >= 500 && enemy2) {
        lives--
        enemy2 = false;
    } else {
        enemy2 = false;
        y2 = y2 - 5000;
        x2 = x2 - 5000;
    }

    if (enemy3 && y3 <= 500) {
        ctx.drawImage(alien, x3, y3, 50, 50)
        y3 = y3 + 0.15
    } else if (y3 >= 500 && enemy3) {
        lives--
        enemy3 = false;
    }  else {
        enemy3 = false;
        y3 = y3 - 5000;
        x3 = x3 - 5000;
    }

    if (enemy4 && y4 <= 500) {
        ctx.drawImage(alien, x4, y4, 50, 50)
        y4 = y4 + 0.15
    } else if (y4 >= 500 && enemy4) {
        lives--
        enemy4 = false;
    }  else {
        enemy4 = false;
        y4 = y4 - 5000;
        x4 = x4 - 5000;
    }

    if (enemy5 && y5 <= 500) {
        ctx.drawImage(alien, x5, y5, 50, 50)
        y5 = y5 + 0.15
    } else if (y5 >= 500 && enemy5) {
        lives--
        enemy5 = false;
    }  else {
        enemy5 = false;
        y5 = y5 - 5000;
        x5 = x5 - 5000;
    }

    if (enemy6 && y6 <= 500) {
        ctx.drawImage(alien, x6, y6, 50, 50)
        y6 = y6 + 0.15
    } else if (y6 >= 500 && enemy6) {
        lives--
        enemy6 = false;
    }  else {
        enemy6 = false;
        y6 = y6 - 5000;
        x6 = x6 - 5000;
    }

    if (enemy7 && y7 <= 500) {
        ctx.drawImage(alien, x7, y7, 50, 50)
        y7 = y7 + 0.15
    } else if (y7 >= 500 && enemy7) {
        lives--
        enemy7 = false;
    }  else {
        enemy7 = false;
        y7 = y7 - 5000;
        x7 = x7 - 5000;
    }

    if (enemy8 && y8 <= 500) {
        ctx.drawImage(alien, x8, y8, 50, 50)
        y8 = y8 + 0.15
    } else if (y8 >= 500 && enemy8) {
        lives--
        enemy8 = false;
    }  else {
        enemy8 = false;
        y8 = y8 - 5000;
        x8 = x8 - 5000;
    }

    if (enemy9 && y9 <= 500) {
        ctx.drawImage(alien, x9, y9, 50, 50)
        y9 = y9 + 0.15
    } else if (y9 >= 500 && enemy9) {
        lives--
        enemy9 = false;
    }  else {
        enemy9 = false;
        y9 = y9 - 5000;
        x9 = x9 - 5000;
    }

    if (enemy10 && y10 <= 500) {
        ctx.drawImage(alien, x10, y10, 50, 50)
        y10 = y10 + 0.15
    } else if (y10 >= 500 && enemy10) {
        lives--
        enemy10 = false;
    }  else {
        enemy10 = false;
        y10 = y10 - 5000;
        x10 = x10 - 5000;
    }

    if (enemy11 && y11 <= 500) {
        ctx.drawImage(alien, x11, y11, 50, 50)
        y11 = y11 + 0.15
    } else if (y11 >= 500 && enemy11) {
        lives--
        enemy11 = false;
    }  else {
        enemy11 = false;
        y11 = y11 - 5000;
        x11 = x11 - 5000;
    }

    if (enemy12 && y12 <= 500) {
        ctx.drawImage(alien, x12, y12, 50, 50)
        y12 = y12 + 0.15
    } else if (y12 >= 500 && enemy12) {
        lives--
        enemy12 = false;
    }  else {
        enemy12 = false;
        y12 = y12 - 5000;
        x12 = x12 - 5000;
    }

    if (enemy13 && y13 <= 500) {
        ctx.drawImage(alien, x13, y13, 50, 50)
        y13 = y13 + 0.15
    } else if (y13 >= 500 && enemy13) {
        lives--
        enemy13 = false;
    }  else {
        enemy13 = false;
        y13 = y13 - 5000;
        x13 = x13 - 5000;
    }

    if (enemy14 && y14 <= 500) {
        ctx.drawImage(alien, x14, y14, 50, 50)
        y14 = y14 + 0.15
    } else if (y14 >= 500 && enemy14) {
        lives--
        enemy14 = false;
    }  else {
        enemy14 = false;
        y14 = y14 - 5000;
        x14 = x14 - 5000;
    }

    if (enemy1 == false && enemy1 == false && enemy2 == false && enemy3 == false && enemy4 == false && enemy5 == false && enemy6 == false && enemy7 == false && enemy8 == false && enemy9 == false && enemy10 == false && enemy11 == false && enemy12 == false && enemy13 == false && enemy14 == false && lives >= 1) {
        ctx.drawImage(victory, 300, 200, 200, 200)
    }



// Score loops

    document.getElementById("scoreboard").innerHTML = score;

}


