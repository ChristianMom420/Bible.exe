// Setup Canvas and Graphics Context
let cnv = document.getElementById("canv");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;

let background = document.getElementById("back")

ctx.drawImage(back, 0, 0, cnv.width, cnv.height)