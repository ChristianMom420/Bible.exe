

document.getElementById("cookieBtn").addEventListener("click", addCookie);
document.getElementById("autoClick").addEventListener("click", addAutoClicker);
document.getElementById("granny").addEventListener("click", addGranny);
document.getElementById("farm").addEventListener("click", addFarm);
document.getElementById("upgrade").addEventListener("click", addUpgrade);
document.getElementById("mine").addEventListener("click", addMine);
document.getElementById("factory").addEventListener("click", addFactory)
document.getElementById("bank").addEventListener("click", addBank);




let cookies = 0;
let autoClicker = 0;
let grannys = 0;
let farms = 0;
let factories = 0;
let mines = 0;
let banks = 0;
let cookieValue = 1;
let autoValue = 0;
let strength = 1;
let autoClickPrice = 15;
let grannyPrice = 50;
let farmPrice = 150;
let upgradePrice = 100;
let factoryPrice = 1500;
let minePrice = 500;
let bankPrice = 5000;
let frames = 0;
let msgA = false;
let msgB = false;
let msgC = false;
let msgD = false;
let msgE = false;
let msgF = false;

// Start loop
setInterval(autoCookie, 1000)

function autoCookie() {
    cookies = cookies + autoValue + grannys + farms + mines + factories + banks;

// Messages
    if (cookies >= 100 || msgA == true) {
        document.getElementById("message").innerHTML = "Your basement operation is becoming a success"
        msgA = true;
    }

    if (cookies >= 2500 || msgB == true) {
        document.getElementById("message").innerHTML = "The neighborhood knows about your cookies"
        msgB = true;
        msgA = false;
    }

    if (cookies >= 10000 || msgC == true) {
        document.getElementById("message").innerHTML = "The neighborhood knows about your cookies"
        msgC = true;
        msgA = false;
        msgB = false;
    }

    if (cookies >= 50000 || msgD == true) {
        document.getElementById("message").innerHTML = "Your cookies are famous throughout your city"
        msgD = true;
        msgA = false;
        msgB = false;
        msgC = false;
    }

    if (cookies >= 250000 || msgE == true) {
        document.getElementById("message").innerHTML = "Your cookies are loved nationwide"
        msgE = true;
        msgA = false;
        msgB = false;
        msgC = false;
        msgD = false;
    }

    if (cookies >= 1000000 || msgF == true) {
        document.getElementById("message").innerHTML = "Your cookies have enslaved humanity. Everyone is emotionally and physically dependant on your cookies"
        msgF = true;
        msgA = false;
        msgB = false;
        msgC = false;
        msgD = false;
        msgE = false;
    }

    // Update variables
    document.getElementById("strength").innerHTML = cookieValue.toFixed(0);
    document.getElementById("cursorNum").innerHTML = (autoClicker * 10).toFixed(0);
    document.getElementById("grannyNum").innerHTML = grannys.toFixed(0);
    document.getElementById("farmNum").innerHTML = (farms / 4).toFixed(0);
    document.getElementById("mineNum").innerHTML = (mines / 10).toFixed(0);
    document.getElementById("factoryNum").innerHTML = (factories / 25).toFixed(0);
    document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
    document.getElementById("bankNum").innerHTML = (banks / 100).toFixed(0);
}




function addCookie() {
    cookies = cookies + cookieValue

    // Update cookies
    document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
    
}




function addAutoClicker() {
    if (cookies >= autoClickPrice) {
        cookies = cookies - autoClickPrice
        autoClickPrice = autoClickPrice * 1.15
        autoClickPrice = autoClickPrice.toFixed(0)
        autoClicker = autoClicker + 0.1
        autoValue = strength * autoClicker
        document.getElementById("cursors").innerHTML += '<img src="images/cursor.png">'
        document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
        document.getElementById("priceAC").innerHTML = autoClickPrice;
        document.getElementById("cursorNum").innerHTML = (autoClicker * 10).toFixed(0);

    }
}

function addGranny() {
    if (cookies >= grannyPrice) {
        cookies = cookies - grannyPrice
        grannyPrice = grannyPrice * 1.25
        grannyPrice = grannyPrice.toFixed(0)
        grannys = grannys + 1
        document.getElementById("grannys").innerHTML += '<img src="images/granny.png">'
        document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
        document.getElementById("priceG").innerHTML = grannyPrice;
        document.getElementById("grannyNum").innerHTML = grannys.toFixed(0);
    }
}

function addFarm() {
    if (cookies >= farmPrice) {
        cookies = cookies - farmPrice
        farmPrice = farmPrice * 1.5
        farmPrice = farmPrice.toFixed(0)
        farms = farms + 4
        document.getElementById("farms").innerHTML += '<img src="images/farm.png">'
        document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
        document.getElementById("priceF").innerHTML = farmPrice
        document.getElementById("farmNum").innerHTML = (farms / 4).toFixed(0);
    }
}

function addUpgrade() {
    if (cookies >= upgradePrice) {
        cookies = cookies - upgradePrice
        upgradePrice = upgradePrice * 2
        upgradePrice = upgradePrice.toFixed()
        cookieValue = cookieValue + 1
        autoValue = autoValue + 1
        strength++
        document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
        document.getElementById("priceC").innerHTML = upgradePrice;
        document.getElementById("strength").innerHTML = cookieValue.toFixed(0);
    }
}

function addMine() {
    if (cookies >= minePrice) {
        cookies = cookies - minePrice;
        minePrice = minePrice * 1.75;
        minePrice = minePrice.toFixed(0);
        mines = mines + 10;
        document.getElementById("mines").innerHTML += "<img src='images/mine.png'>";
        document.getElementById("mineNum").innerHTML = mines / 10;
        document.getElementById("priceM").innerHTML = minePrice;
        document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
    }
}

function addFactory() {
    if (cookies >= factoryPrice) {
        cookies = cookies - factoryPrice;
        factoryPrice = factoryPrice * 2;
        factoryPrice = factoryPrice.toFixed(0);
        factories = factories + 25;
        document.getElementById("factories").innerHTML += "<img src='images/factory.png'>";
        document.getElementById("factoryNum").innerHTML = factories / 25;
        document.getElementById("priceFA").innerHTML = factoryPrice;
        document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
    }
}

function addBank() {
    if (cookies >= bankPrice) {
        cookies = cookies - bankPrice;
        bankPrice = bankPrice * 3;
        bankPrice = bankPrice.toFixed(0);
        banks = banks + 100;
        document.getElementById("banks").innerHTML += "<img src='images/bank.PNG'>";
        document.getElementById("bankNum").innerHTML = banks / 100;
        document.getElementById("priceB").innerHTML = bankPrice;
        document.getElementById("cookieNum").innerHTML = cookies.toFixed(0);
    }
}