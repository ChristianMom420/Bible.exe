// Setup Canvas and Graphics Context
let cnv = document.getElementById("canv");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;

document.addEventListener("keydown", keydownhandler);

let rand = 0;
let candy = document.getElementById("candy1")
let candyX = 0;
let candyY = 0;
let box = document.getElementById("bowl")
let back = document.getElementById("back")
let life = document.getElementById("life")
let empty = document.getElementById("lifeempty")
let loss = document.getElementById("lose")
let boxX = 300
let boxY = 400
let score = 0
let lives = 3;
let winning = true;
let increment = 3;
let highscore = 0;

function reset() {
    lives = 3
    score = 0;
    dropCandy()
    candyY = 0;
    winning = true;
    loop()
    increment = 3;
}



requestAnimationFrame(dropCandy)
function dropCandy() {
    rand = Math.random();
    candyX = Math.floor((Math.random() * 700) + 50)

    if (rand <= 0.166666666666666666666666666666666666666666666666666666666666666666666666666666666666666) {
        candy = document.getElementById("candy1");
    } else if (rand <= 0.333333333333333333333333333333333333333333333333333333333333333333333333333333333) {
        candy = document.getElementById("candy2");
    } else if (rand <= 0.50) {
        candy = document.getElementById("candy3");
    } else if (rand <= 0.66666666666666666666666666666666666666666666666666666666666666666666666) {
        candy = document.getElementById("candy4");
    } else if (rand <= 0.83333333333333333333333333333333333333333333333333333333333333333333) {
        candy = document.getElementById("candy5");
    } else {
        candy = document.getElementById("candy6");
    }
}



function keydownhandler(event) {
    if (event.code == "ArrowLeft") {
        if (boxX >= 20) {
        boxX = boxX - 100;
        }
    } else if (event.code == "ArrowRight") {
        if (boxX <= 500) {
        boxX = boxX + 100;
        }
    }
}

requestAnimationFrame(image1)

function image1() {
    document.getElementById("bowl").src = "candyImages/amalgam1.png"
    setTimeout(image2, 50)
}

function image2() {
    document.getElementById("bowl").src = "candyImages/amalgam2.png"
    setTimeout(image3, 50)
}

function image3() {
    document.getElementById("bowl").src = "candyImages/amalgam3.png"
    setTimeout(image4, 50)
}

function image4() {
    document.getElementById("bowl").src = "candyImages/amalgam2.png"
    setTimeout(image1, 50)
}


if (winning){
requestAnimationFrame(loop)
}

function loop() {

    document.getElementById("score").innerHTML = score;
    document.getElementById("hiscore").innerHTML = highscore;
ctx.drawImage(back, 0, 0, cnv.width, cnv.height)
ctx.drawImage(box, boxX, boxY, 200, 200)
ctx.drawImage(candy, candyX, candyY, 75, 75)
candyY = candyY + increment

if (highscore <= score) {
    highscore = score
}
console.log(highscore)

if (candyY >= 430 && candyX <= boxX + 200 && candyX >= boxX - 10) {
    candyY = 0
    dropCandy()
    score = score + 10
    if (increment <= 15){
    increment = increment + 0.3
    }
} else if (candyY >= 500) {
    score = score - 10;
    candyY = 0;
    dropCandy()
    lives--
}

if (lives == 3) {
    ctx.drawImage(life, 10, 10, 50, 50)
    ctx.drawImage(life, 60, 10, 50, 50)
    ctx.drawImage(life, 110, 10, 50, 50)
} else if (lives == 2) {
    ctx.drawImage(life, 10, 10, 50, 50)
    ctx.drawImage(life, 60, 10, 50, 50)
    ctx.drawImage(empty, 110, 10, 50, 50)
} else if (lives == 1) {
    ctx.drawImage(life, 10, 10, 50, 50)
    ctx.drawImage(empty, 60, 10, 50, 50)
    ctx.drawImage(empty, 110, 10, 50, 50)
} else{
    ctx.drawImage(empty, 10, 10, 50, 50)
    ctx.drawImage(empty, 60, 10, 50, 50)
    ctx.drawImage(empty, 110, 10, 50, 50)
    lose()
}
if (winning) {
requestAnimationFrame(loop)
}
}

function lose() {
    winning = false;
    ctx.drawImage(loss, 300, 200, 200, 200)
}